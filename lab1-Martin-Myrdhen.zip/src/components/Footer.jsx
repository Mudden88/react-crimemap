function Footer() {
  return (
    <>
      <div className='footerwrap'>
        <p>
          <a href='https://brottsplatskartan.se/sida/api' target='_blanc'>
            API utav brottsplatskartan.se - Tryck här för mer information
          </a>
        </p>

        <p>Gjort med React & Vite av Martin Myrdhén, FEU23</p>
      </div>
    </>
  );
}
export default Footer;
